// Supabase 프로젝트 설정 > API Keys에서 값을 복사하세요.
// 아래 공개용 anon/publishable 키만 입력하세요. service_role / secret 키는 절대 입력하지 마세요.
window.DAEUN_CONFIG = {
  supabaseUrl: "",
  supabaseAnonKey: ""
};
