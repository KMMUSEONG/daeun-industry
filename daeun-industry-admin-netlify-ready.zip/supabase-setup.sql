-- Supabase > SQL Editor > New query에서 전체 실행하세요.
create table if not exists public.products (
 id uuid primary key default gen_random_uuid(),
 name_ko text not null, name_ja text not null,
 spec_ko text not null default '', spec_ja text not null default '',
 description_ko text not null default '', description_ja text not null default '',
 image_path text, sort_order integer not null default 0,
 created_at timestamptz not null default now()
);
create table if not exists public.admin_users (
 user_id uuid primary key references auth.users(id) on delete cascade
);
alter table public.products enable row level security;
alter table public.admin_users enable row level security;
revoke all on public.admin_users from anon;
grant select on public.admin_users to authenticated;
grant select on public.products to anon, authenticated;
grant insert,update,delete on public.products to authenticated;
drop policy if exists "Anyone can read products" on public.products;
create policy "Anyone can read products" on public.products for select to anon,authenticated using (true);
drop policy if exists "Only admins can add products" on public.products;
create policy "Only admins can add products" on public.products for insert to authenticated with check (exists(select 1 from public.admin_users where user_id=(select auth.uid())));
drop policy if exists "Only admins can edit products" on public.products;
create policy "Only admins can edit products" on public.products for update to authenticated using (exists(select 1 from public.admin_users where user_id=(select auth.uid()))) with check (exists(select 1 from public.admin_users where user_id=(select auth.uid())));
drop policy if exists "Only admins can delete products" on public.products;
create policy "Only admins can delete products" on public.products for delete to authenticated using (exists(select 1 from public.admin_users where user_id=(select auth.uid())));
drop policy if exists "Admins can check own access" on public.admin_users;
create policy "Admins can check own access" on public.admin_users for select to authenticated using (user_id=(select auth.uid()));
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('product-images','product-images',true,5242880,array['image/jpeg','image/png','image/webp'])
on conflict(id) do update set public=true,file_size_limit=5242880,allowed_mime_types=array['image/jpeg','image/png','image/webp'];
drop policy if exists "Admins upload product photos" on storage.objects;
create policy "Admins upload product photos" on storage.objects for insert to authenticated with check (bucket_id='product-images' and exists(select 1 from public.admin_users where user_id=(select auth.uid())));
drop policy if exists "Admins remove product photos" on storage.objects;
create policy "Admins remove product photos" on storage.objects for delete to authenticated using (bucket_id='product-images' and exists(select 1 from public.admin_users where user_id=(select auth.uid())));
-- 아래 초기 제품은 최초 1회만 등록 (중복 실행 시 추가되지 않음)
insert into public.products(name_ko,name_ja,sort_order)
select v.name_ko,v.name_ja,v.sort_order from (values
 ('28구 딸기 육묘포트','28穴 イチゴ育苗ポット',0),
 ('32구 딸기 육묘포트','32穴 イチゴ育苗ポット',1),
 ('24구 딸기 육묘포트','24穴 イチゴ育苗ポット',2),
 ('6구 화분','6穴 ポット',3),
 ('8구 화분','8穴 ポット',4),
 ('대운스마트 점적호스 / 점적테이프','点滴灌水ホース・テープ',5)
) as v(name_ko,name_ja,sort_order)
where not exists (select 1 from public.products);
