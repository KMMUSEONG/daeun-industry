# 대운산업 홈페이지 설치 안내 (처음 1회)

## 무엇이 들어 있나요?
- `index.html`: 기존 디자인을 유지한 홈페이지 + 관리자 화면
- `app.js`: 언어 전환, 로그인, 제품 등록·수정·삭제, 사진 업로드
- `config.js`: Supabase 연결 정보를 붙여 넣는 파일
- `supabase-setup.sql`: 데이터베이스·사진 저장소·보안 설정
- `register-admin.sql`: 관리자 권한 부여 예시
- `netlify.toml`: Netlify 배포 설정 및 보안 헤더

## 1단계: Supabase 만들기
1. https://supabase.com 에 가입하고 **New project**를 선택합니다.
2. 프로젝트 이름을 정하고 Database Password를 안전하게 보관합니다.
3. 왼쪽 **SQL Editor** → **New query**에서 `supabase-setup.sql` 전체 내용을 붙여 넣고 **Run**을 누릅니다.
4. 오류가 없으면 제품 목록과 사진 저장소, 관리자 보안 정책이 만들어집니다.

## 2단계: 관리자 계정 생성
1. Supabase의 **Authentication → Users → Add user**에서 본인 이메일과 강력한 비밀번호를 설정해 사용자를 만듭니다.
2. 생성된 사용자를 눌러 **User UID**를 복사합니다.
3. `register-admin.sql`을 메모장으로 열어 `UUID_REPLACE_ME`를 실제 User UID로 교체합니다. **따옴표는 그대로 둡니다.**
4. 수정한 SQL을 Supabase **SQL Editor**에서 실행합니다.
5. 관리자 이메일은 공개 페이지에 표시되지 않습니다. 관리자는 제품만 변경할 수 있고 일반 방문자는 읽기만 가능합니다.

## 3단계: 홈페이지 연결하기
1. Supabase의 **Project Settings → API Keys**에서 **Project URL**과 **anon/public 또는 publishable 키**를 확인합니다. (화면 위치·명칭은 바뀔 수 있습니다.)
2. ZIP 압축을 풀고 `config.js`를 메모장으로 엽니다.
3. `supabaseUrl: ""`에 Project URL, `supabaseAnonKey: ""`에 공개용 키를 붙여 넣고 저장합니다.
4. **service_role, secret 키, 데이터베이스 비밀번호는 절대 이 파일에 넣지 마세요.** 공개용 키는 브라우저에서 보이는 것이 정상이며 실제 수정 권한은 서버 RLS가 막습니다.

## 4단계: Netlify에 배포하기
1. https://app.netlify.com 에 가입하고 **Add new project → Deploy manually**(또는 Drag and drop)를 선택합니다.
2. `index.html`, `app.js`, `config.js`, `netlify.toml`이 들어 있는 **폴더**를 업로드합니다. SQL 파일과 안내서는 배포에 필요 없으므로 빼도 됩니다.
3. Netlify가 제공하는 `https://...netlify.app` 주소로 접속합니다.
4. 상단 **관리자** → 이메일/비밀번호로 로그인하여 제품을 등록합니다.
5. 비밀번호 재설정 메일을 쓰려면 Supabase **Authentication → URL Configuration**에서 Site URL을 실제 Netlify 주소로 설정하고, 필요 시 Redirect URLs도 추가합니다. 이메일 템플릿과 발송 제한도 확인하세요.

## 평소 제품을 바꾸는 방법
- 홈페이지 → 상단 **관리자** → 로그인 → **새 제품 등록** 또는 기존 제품 **수정/삭제**
- 한국어/일본어 제품명, 규격, 설명을 각각 입력합니다. 사진은 JPG/PNG/WEBP, 5MB 이하만 가능합니다.
- **저장하기**를 누르면 Supabase 서버에 저장됩니다. 방문자는 새로고침 시 최신 내용을 봅니다.
- 비밀번호 변경은 관리자 로그인 후 **비밀번호 변경**을 사용합니다.
- 제품 사진을 바꾸면 이전 사진 파일은 자동 정리를 시도합니다.

## 중요한 주의사항
- 이 ZIP 자체에 서버 계정이나 비밀번호가 포함되어 있지 않습니다. **Supabase 설정을 완료해야 실제 로그인·영구 저장이 작동합니다.**
- 최초 연결 전에는 기존 6개 제품이 미리보기로 표시됩니다.
- 방문자에게 수정 버튼이 보이지 않으며, 서버 RLS와 Storage 정책이 비관리자의 변경 요청을 차단합니다.
- Netlify에 배포한 뒤 제품 변경에는 재배포가 필요 없습니다.
- 제품 데이터와 사진은 Supabase에 저장되므로 Supabase 프로젝트를 삭제하면 데이터도 사라집니다. 중요한 자료는 정기적으로 백업하세요.
- 무료 플랜의 사용량 한도와 비활성 프로젝트 정책은 Supabase/Netlify의 최신 요금 안내를 확인하세요.
- 계정 이메일 확인/초대 방식에 따라 메일 설정이 필요할 수 있습니다.
