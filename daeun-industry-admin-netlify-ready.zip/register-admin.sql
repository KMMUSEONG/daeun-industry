-- 1. Supabase > Authentication > Users > Add user에서 이메일과 비밀번호로 사용자 생성
-- 2. 해당 사용자 상세 화면에서 User UID 복사
-- 3. 아래 UUID_REPLACE_ME를 복사한 UID로 교체 후 SQL Editor에서 실행
insert into public.admin_users(user_id) values ('UUID_REPLACE_ME') on conflict do nothing;
